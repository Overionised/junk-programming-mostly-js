<!DOCTYPE html>
<html lang="en">
<title>cv3</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="styles.css">
<script src="w3-script.js"></script>

<body id="home" class="w3-content">

<!-- Navigation (Stays on Top) -->
<div class="w3-top w3-bar w3-black">
    <a href="#home" class="w3-bar-item w3-button">cv3</a>
</div>

<section id="about" class="w3-container w3-padding-32">
    <h2>cv3</h2>
    <p id="out1" style="display: grid; grid-template-columns: repeat(11, 40px); gap: 5px;"></p>
</section>

<script>
    for (let i = 1; i < 11; i++) {
        document.getElementById('out1').innerHTML += `<span>${i}</span>`;

        for (let j = 1; j < 11; j++) {
            document.getElementById('out1').innerHTML += `<span>${i * j}</span>`;
        }
    }
</script>

</script>
</body>
</html>
